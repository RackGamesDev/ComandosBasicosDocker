#!/bin/bash
echo esto se ejecuta cada vez que se enciende el contenedor, si esta en la carpeta /docker-entrypoint.d/
